using UnityEngine;
using Nexus7.Player;

namespace Nexus7.Interaction
{
    /// <summary>
    /// Taquilla con el traje espacial (Fase 1). Al usarla el jugador se pone el traje y la taquilla queda vacía.
    /// Colocar en: la taquilla (con collider). 'Player Suit' = PlayerSuit del jugador · 'Suit Visual' = el traje colgado.
    /// </summary>
    public class SuitPickup : Interactable
    {
        [SerializeField] private PlayerSuit playerSuit;
        [SerializeField] private GameObject suitVisual;

        private bool taken;

        public override string Prompt => "Ponerse el traje espacial";
        public override bool CanInteract(PlayerInteractor interactor) => !taken && base.CanInteract(interactor);

        protected override void OnInteract(PlayerInteractor interactor)
        {
            if (taken) return;
            if (playerSuit == null && interactor != null) playerSuit = interactor.GetComponentInParent<PlayerSuit>();
            if (playerSuit == null) return;
            taken = true;
            playerSuit.PutOn(true);
            if (suitVisual != null) suitVisual.SetActive(false);
        }
    }
}
